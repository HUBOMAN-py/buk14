package org.bukkit;

/**
 * Tree type.
 * 
 * @author sk89q
 */
public enum TreeType {
    TREE,
    BIG_TREE,
    REDWOOD,
    TALL_REDWOOD,
    BIRCH
}
