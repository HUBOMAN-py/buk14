package org.bukkit.block;

/**
 * Represents a chest.
 * 
 * @author sk89q
 */
public interface Chest extends BlockState, ContainerBlock {
}
