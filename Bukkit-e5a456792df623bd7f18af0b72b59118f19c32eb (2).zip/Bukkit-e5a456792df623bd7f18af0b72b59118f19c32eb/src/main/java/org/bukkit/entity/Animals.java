package org.bukkit.entity;

/**
 * Represents an Animal.
 * 
 * @author Cogito
 *
 */
public interface Animals extends Creature{

}
