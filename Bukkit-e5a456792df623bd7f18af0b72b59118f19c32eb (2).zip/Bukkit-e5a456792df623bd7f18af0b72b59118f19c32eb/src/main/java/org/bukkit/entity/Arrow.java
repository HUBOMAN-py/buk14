package org.bukkit.entity;

/**
 * Represents an arrow.
 * 
 * @author sk89q
 */
public interface Arrow extends Entity {
}
