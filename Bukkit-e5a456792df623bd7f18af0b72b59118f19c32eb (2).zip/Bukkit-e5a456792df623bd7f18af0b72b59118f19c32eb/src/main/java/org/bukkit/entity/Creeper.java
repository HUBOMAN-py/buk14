/**
 * 
 */
package org.bukkit.entity;

/**
 * Represents a Creeper.
 * 
 * @author Cogito
 *
 */
public interface Creeper extends Monster {

}
