package org.bukkit.entity;

/**
 * Represents an egg.
 * 
 * @author sk89q
 */
public interface Egg extends Entity {
}
