package org.bukkit.entity;

/**
 * Represents a Fireball.
 * 
 * @author Cogito
 */
public interface Fireball extends Entity {
}
