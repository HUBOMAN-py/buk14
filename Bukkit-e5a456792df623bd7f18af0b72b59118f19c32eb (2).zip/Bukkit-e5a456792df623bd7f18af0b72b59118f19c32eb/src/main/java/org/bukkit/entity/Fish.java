package org.bukkit.entity;

/**
 * Represents a Fish.
 * 
 * @author Cogito
 */
public interface Fish extends Entity {
}
