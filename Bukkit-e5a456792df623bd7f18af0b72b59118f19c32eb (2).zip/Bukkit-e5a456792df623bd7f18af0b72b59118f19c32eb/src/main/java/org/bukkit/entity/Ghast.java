/**
 * 
 */
package org.bukkit.entity;

/**
 * Represents a Ghast.
 * 
 * @author Cogito
 *
 */
public interface Ghast extends Flying {

}
