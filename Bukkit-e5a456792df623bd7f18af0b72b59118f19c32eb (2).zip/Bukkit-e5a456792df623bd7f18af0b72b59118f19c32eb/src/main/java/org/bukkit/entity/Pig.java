/**
 * 
 */
package org.bukkit.entity;

/**
 * Represents a Pig.
 * 
 * @author Cogito
 *
 */
public interface Pig extends Animals {

}
