/**
 * 
 */
package org.bukkit.entity;

/**
 * Represents a Pig Zombie.
 * 
 * @author Cogito
 *
 */
public interface PigZombie extends Zombie {

}
