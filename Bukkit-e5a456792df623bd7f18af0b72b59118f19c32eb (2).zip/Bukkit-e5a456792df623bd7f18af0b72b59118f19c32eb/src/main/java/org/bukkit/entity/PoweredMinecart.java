package org.bukkit.entity;

/**
 * Represents a powered minecart.
 * 
 * @author sk89q
 */
public interface PoweredMinecart extends Minecart {

}
