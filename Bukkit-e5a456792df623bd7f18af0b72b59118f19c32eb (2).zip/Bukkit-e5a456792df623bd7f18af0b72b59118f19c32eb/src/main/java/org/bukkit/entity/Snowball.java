package org.bukkit.entity;

/**
 * Implements a snowball.
 * 
 * @author sk89q
 */
public interface Snowball extends Entity {
}
