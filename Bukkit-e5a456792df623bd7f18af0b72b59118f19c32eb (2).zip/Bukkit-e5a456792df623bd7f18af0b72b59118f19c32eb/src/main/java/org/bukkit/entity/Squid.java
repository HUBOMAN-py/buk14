/**
 * 
 */
package org.bukkit.entity;

/**
 * Represents a Squid.
 * 
 * @author Cogito
 *
 */
public interface Squid extends WaterMob {

}
