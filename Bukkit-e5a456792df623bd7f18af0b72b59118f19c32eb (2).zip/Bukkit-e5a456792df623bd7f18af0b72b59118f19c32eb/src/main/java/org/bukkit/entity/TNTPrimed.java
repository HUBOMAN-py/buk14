/**
 * 
 */
package org.bukkit.entity;

/**
 * Represents a Primed TNT.
 * 
 * @author Cogito
 *
 */
public interface TNTPrimed extends Entity {

}
