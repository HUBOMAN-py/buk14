package org.bukkit.event.player;

/*
 * Differet types of player animations
 */
public enum PlayerAnimationType {
	ARM_SWING
}
